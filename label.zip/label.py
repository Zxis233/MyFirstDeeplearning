import json
import webbrowser
import os
import csv
import pandas as pd

###################################
# 请输入你标注的文件名字
path = "1.1.json"
###################################
data = json.load(open(path))


def label_one_user(uid):
    url = 'https://weibo.com/u/{}?profile_ftype=1&is_all=1#_0'.format(uid)
    webbrowser.open(url, new=0, autoraise=True)
    while True:
        label = input('请输入用户{}的标签。1-5，越高代表越机器人：'.format(uid))
        try:
            label = int(label)
        except Exception as e:
            print(e)
            continue
        if label in [1, 2, 3, 4, 5]:
            break
        print('请输入1-5之间的整数！')
    return str(label)


if __name__ == '__main__':
    name = input('请输入你的名字（用于保存记录）：')
    if not os.path.exists("./record_{}.csv".format(name)):
        with open("./record_{}.csv".format(name), "a+", newline="") as f:
            headers = ["id", "label"]
            writer = csv.writer(f)
            writer.writerow(headers)
    for item in data:
        labeled = pd.read_csv("./record_{}.csv".format(name))
        if item in labeled["id"].tolist():
            continue
        label_str = label_one_user(item)
        record = open("./record_{}.csv".format(name), "a+", newline="")
        writer = csv.writer(record)
        writer.writerow([item, label_str])
        record.close()
